library(shiny)
library(ggplot2)
library(dplyr)
library(DT)
library(shinycssloaders)
library(shinyjs)
library(officer)

# Funkcja do obliczania statystyk
calculate_statistics <- function(data) {
  quantiles <- c(0.01, 0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 0.95, 0.99, 0.995)
  stats <- data.frame(
    Statystyki = c("min", "max", quantiles, "mean", "0.995-mean")
  )
  
  for (col in names(data)) {
    col_quantiles <- quantile(data[[col]], quantiles)
    col_stats <- c(min(data[[col]]), max(data[[col]]), col_quantiles, mean(data[[col]]), quantile(data[[col]], 0.995) - mean(data[[col]]))
    stats[[col]] <- col_stats
  }
  
  # Formatuj kolumnę "Statystyki" jako procenty z prefiksem "Q:" dla kwantyli
  stats$Statystyki <- as.character(stats$Statystyki)
  stats$Statystyki[stats$Statystyki %in% quantiles] <- paste0("Q:", sprintf("%.1f%%", as.numeric(stats$Statystyki[stats$Statystyki %in% quantiles]) * 100))
  
  return(stats)
}

library(rmarkdown)

generate_pdf_report <- function(data_list, base_path) {
  timestamp <- format(Sys.time(), "%Y%m%d_%H%M")
  save_path <- paste0(base_path, "_", timestamp, ".pdf")
  
  rmarkdown::render("templete.Rmd", output_file = save_path, params = list(data_list = data_list))
}


generate_report <- function(data_list, base_path = "RaportRyzykoPozaru") {
  timestamp <- format(Sys.time(), "%Y%m%d_%H%M")
  save_path <- paste0(base_path, "_", timestamp, ".docx")
  
  summary_data <- data.frame(
    Ubezpieczyciel = names(data_list),
    Brutto = numeric(length(data_list)),
    Brutto_Katastroficzne = numeric(length(data_list)),
    Netto = numeric(length(data_list)),
    Netto_Katastroficzne = numeric(length(data_list))
  )
  
  doc <- read_docx()
  
  # Dodaj tytuł raportu
  liczba_ubezpieczycieli <- length(data_list)
  doc <- doc %>%
    body_add_par("RAPORT RYZYKO POŻARU", style = "heading 1") %>%
    body_add_par(Sys.Date(), style = "Normal") %>%
    body_add_par(paste0("Poniższy raport przedstawia analizę przeprowadzoną dla ", 
                        liczba_ubezpieczycieli, 
                        " ubezpieczycieli dla roku 2022. W rozdziale 2 zostały przedstawione wyniki SCR dla poszczególnych ubezpieczycieli. W kolejnych rozdziałach prezentowane są szczegółowe wyniki."), 
                 style = "Normal") %>%
    body_add_par("", style = "Normal")  # Pusta linia
  
  # Dodaj spis treści
  doc <- doc %>%
    body_add_par("Spis Treści", style = "heading 1") %>%
    body_add_toc(level = 2) %>%
    body_add_par("", style = "Normal")  # Pusta linia
  
  # Dodaj podsumowanie na początku raportu
  for (insurance_name in names(data_list)) {
    data <- data_list[[insurance_name]]
    stats <- calculate_statistics(data)
    
    cat("Processing:", insurance_name, "\n")  # Log nazwy przetwarzanego ubezpieczyciela
    print(stats)  # Log statystyk
    
    if ("0.995-mean" %in% stats$Statystyki) {
      brutto_value <- as.numeric(stats[stats$Statystyki == "0.995-mean", "Brutto"])
      brutto_kat_value <- as.numeric(stats[stats$Statystyki == "0.995-mean", "Brutto_Katastroficzny"])
      netto_value <- as.numeric(stats[stats$Statystyki == "0.995-mean", "Netto"])
      netto_kat_value <- as.numeric(stats[stats$Statystyki == "0.995-mean", "Netto_Katastroficzny"])
      
      summary_data[summary_data$Ubezpieczyciel == insurance_name, "Brutto"] <- brutto_value
      summary_data[summary_data$Ubezpieczyciel == insurance_name, "Brutto_Katastroficzne"] <- brutto_kat_value
      summary_data[summary_data$Ubezpieczyciel == insurance_name, "Netto"] <- netto_value
      summary_data[summary_data$Ubezpieczyciel == insurance_name, "Netto_Katastroficzne"] <- netto_kat_value
      
      cat("Assigned values for:", insurance_name, "\n")
      cat("Brutto:", brutto_value, "\n")
      cat("Brutto_Katastroficzne:", brutto_kat_value, "\n")
      cat("Netto:", netto_value, "\n")
      cat("Netto_Katastroficzne:", netto_kat_value, "\n")
    } else {
      cat("0.995-mean not found for:", insurance_name, "\n")
    }
  }
  
  doc <- doc %>%
    body_add_par("Podsumowanie", style = "heading 1") %>%
    body_add_table(value = summary_data, style = "table_template") %>%
    body_add_par("", style = "Normal")  # Pusta linia
  
  for (insurance_name in names(data_list)) {
    data <- data_list[[insurance_name]]
    stats <- calculate_statistics(data)
    
    doc <- doc %>%
      body_add_par(insurance_name, style = "heading 1") %>%
      body_add_par("Statystyki", style = "heading 2") %>%
      body_add_table(value = stats, style = "table_template") %>%
      body_add_par("Histogramy", style = "heading 2")
    
    for (col in names(data)) {
      hist_file <- tempfile(fileext = ".png")
      png(hist_file, width = 800, height = 600)
      hist(data[[col]], main = paste("Histogram", col), xlab = col, col = "blue", border = "black")
      dev.off()
      doc <- doc %>%
        body_add_par(col, style = "heading 3") %>%
        body_add_img(src = hist_file, width = 6, height = 4)
    }
    
    # Dodaj wykres kwantyli
    quantiles <- c(0.01, 0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 0.95, 0.99, 0.995)
    quantile_data <- data.frame(
      Quantile = rep(quantiles, times = ncol(data)),
      Value = unlist(lapply(data, quantile, quantiles)),
      Variable = rep(names(data), each = length(quantiles))
    )
    
    quantile_plot_file <- tempfile(fileext = ".png")
    png(quantile_plot_file, width = 800, height = 600)
    print(ggplot(quantile_data, aes(x = Quantile, y = Value, color = Variable)) +
            geom_line() +
            geom_point() +
            labs(title = "Kwantyle dla każdej kolumny", x = "Kwantyl", y = "Wartość szkody") +
            theme(legend.position = "left"))
    dev.off()
    
    doc <- doc %>%
      body_add_par("Kwantyle", style = "heading 2") %>%
      body_add_img(src = quantile_plot_file, width = 6, height = 4)
  }
  
  print(doc, target = save_path)
}










# UI
ui <- fluidPage(
  useShinyjs(),
  inlineCSS(list(
    ".overlay" = "position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0, 0, 0, 0.5); z-index: 1000;",
    ".spinner" = "position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); z-index: 1001;"
  )),
  titlePanel("Aplikacja do wizualizacji"),
  
  navbarPage("Symulacje",
             tabPanel("Symulacje",
                      sidebarLayout(
                        sidebarPanel(
                          textInput("folder_path", "Ścieżka do folderu:", ""),
                          actionButton("load_data", "Pobierz dane"),
                          selectInput("insurance", "Wybierz ubezpieczyciela:", choices = NULL),
                          selectInput("column", "Wybierz kolumnę:", choices = NULL),
                          textInput("save_path", "Ścieżka do zapisu raportu:", ""),
                          selectInput("report_format", "Wybierz format raportu:", choices = c("Word", "PDF")),
                          actionButton("generate_report", "Generuj raport")
                        ),
                        mainPanel(
                          tabsetPanel(
                            id = "tabs", # Identyfikator zakładek
                            tabPanel("Histogram",
                                     h2("Histogram"),
                                     withSpinner(plotOutput("histogramPlot"))
                            ),
                            tabPanel("Statystyki",
                                     h2("Statystyki"),
                                     withSpinner(DTOutput("statsTable"))
                            ),
                            tabPanel("Kwantyle",
                                     h2("Kwantyle"),
                                     withSpinner(plotOutput("quantilePlot"))
                            )
                          )
                        )
                      )
             )
  ),
  div(id = "loadingOverlay", class = "overlay", style = "display: none;"),
  div(id = "loadingSpinner", class = "spinner", style = "display: none;", tags$img(src = "https://cdnjs.cloudflare.com/ajax/libs/timelinejs/2.36.0/css/loading.gif", height = "100"))
)

# Server
server <- function(input, output, session) {
  data_list <- reactiveVal(list())
  filtered_data <- reactiveVal(NULL)
  
  observeEvent(input$load_data, {
    # Wyświetl spinner i overlay
    shinyjs::show(id = "loadingOverlay")
    shinyjs::show(id = "loadingSpinner")
    
    # Pobierz ścieżkę do folderu
    folder_path <- input$folder_path
    if (dir.exists(folder_path)) {
      # Pobierz wszystkie pliki CSV w folderze
      csv_files <- list.files(folder_path, pattern = "\\.csv$", full.names = TRUE)
      
      # Wczytaj dane z plików CSV
      all_data <- lapply(csv_files, read.csv)
      names(all_data) <- gsub("\\.csv$", "", basename(csv_files))
      
      # Uaktualnij dane i listę ubezpieczycieli
      data_list(all_data)
      updateSelectInput(session, "insurance", choices = names(all_data))
      
      # Ukryj spinner i overlay
      shinyjs::hide(id = "loadingOverlay")
      shinyjs::hide(id = "loadingSpinner")
    }
  })
  
  observeEvent(input$insurance, {
    req(input$insurance)
    filtered_data(data_list()[[input$insurance]])
    updateSelectInput(session, "column", choices = names(filtered_data()))
  })
  
  # Wykres histogramu
  # Wykres histogramu
  output$histogramPlot <- renderPlot({
    req(filtered_data())
    column <- input$column
    req(column)
    
    ggplot(filtered_data(), aes_string(x = column)) +
      geom_histogram(binwidth = 5000, fill = "blue", color = "black", alpha = 0.7) +
      labs(title = paste("Rozkład", column), x = column, y = "Częstotliwość")
  })
  
  # Wyświetlanie statystyk
  output$statsTable <- renderDT({
    req(filtered_data())
    stats <- calculate_statistics(filtered_data())
    datatable(stats)
  })
  
  # Wykres kwantyli
  output$quantilePlot <- renderPlot({
    req(filtered_data())
    data <- filtered_data()
    quantiles <- c(0.01, 0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 0.95, 0.99, 0.995)
    
    quantile_data <- data.frame(
      Quantile = rep(quantiles, times = ncol(data)),
      Value = unlist(lapply(data, quantile, quantiles)),
      Variable = rep(names(data), each = length(quantiles))
    )
    
    ggplot(quantile_data, aes(x = Quantile, y = Value, color = Variable)) +
      geom_line() +
      geom_point() +
      labs(title = "Kwantyle dla każdej kolumny", x = "Kwantyl", y = "Wartość szkody") +
      theme(legend.position = "left")
  })
  
  observeEvent(input$generate_report, {
    req(data_list())
    req(input$save_path)
    
    report_format <- input$report_format
    
    if (report_format == "Word") {
      generate_report(data_list(), input$save_path)
    } else if (report_format == "PDF") {
      generate_pdf_report(data_list(), input$save_path)
    }
    
    showModal(modalDialog(
      title = "Raport wygenerowany",
      "Raport został pomyślnie zapisany w podanej lokalizacji.",
      easyClose = TRUE,
      footer = NULL
    ))
  })
}

# Uruchomienie aplikacji Shiny
shinyApp(ui = ui, server = server)
