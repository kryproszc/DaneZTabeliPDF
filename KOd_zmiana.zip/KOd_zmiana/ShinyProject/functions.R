library(ggplot2)
library(dplyr)
library(officer)

# Funkcja do obliczania statystyk
calculate_statistics <- function(data) {
  quantiles <- c(0.01, 0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 0.95, 0.99, 0.995)
  stats <- data.frame(
    Statystyki = c("min", "max", quantiles, "mean", "0.995-mean")
  )
  
  for (col in names(data)) {
    col_quantiles <- quantile(data[[col]], quantiles)
    col_stats <- c(min(data[[col]]), max(data[[col]]), col_quantiles, mean(data[[col]]), quantile(data[[col]], 0.995) - mean(data[[col]]))
    stats[[col]] <- col_stats
  }
  
  # Formatuj kolumnę "Statystyki" jako procenty z prefiksem "Q:" dla kwantyli
  stats$Statystyki <- ifelse(stats$Statystyki %in% quantiles, paste0("Q:", sprintf("%.1f%%", as.numeric(as.character(stats$Statystyki)) * 100)), as.character(stats$Statystyki))
  
  return(stats)
}

# Funkcja do generowania raportu
generate_report <- function(data_list, save_path) {
  if (!grepl("\\.docx$", save_path)) {
    save_path <- paste0(save_path, ".docx")
  }
  
  doc <- read_docx()
  
  for (insurance_name in names(data_list)) {
    data <- data_list[[insurance_name]]
    stats <- calculate_statistics(data)
    
    doc <- doc %>%
      body_add_par(insurance_name, style = "heading 1") %>%
      body_add_par("Statystyki", style = "heading 2") %>%
      body_add_table(value = stats, style = "table_template") %>%
      body_add_par("Histogramy", style = "heading 2")
    
    for (col in names(data)) {
      hist_file <- tempfile(fileext = ".png")
      png(hist_file, width = 800, height = 600)
      hist(data[[col]], main = paste("Histogram", col), xlab = col, col = "blue", border = "black")
      dev.off()
      doc <- doc %>%
        body_add_par(col, style = "heading 3") %>%
        body_add_img(src = hist_file, width = 6, height = 4)
    }
  }
  
  print(doc, target = save_path)
}
