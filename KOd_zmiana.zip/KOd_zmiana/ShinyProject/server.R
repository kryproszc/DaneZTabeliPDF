library(shiny)
library(ggplot2)
library(dplyr)
library(DT)
library(officer)
source("functions.R")

# Serwer
server <- function(input, output, session) {
  data_list <- reactiveVal(list())
  filtered_data <- reactiveVal(NULL)
  
  observeEvent(input$load_data, {
    # Wyświetl spinner i overlay
    shinyjs::show(id = "loadingOverlay")
    shinyjs::show(id = "loadingSpinner")
    
    # Pobierz ścieżkę do folderu
    folder_path <- input$folder_path
    if (dir.exists(folder_path)) {
      # Pobierz wszystkie pliki CSV w folderze
      csv_files <- list.files(folder_path, pattern = "\\.csv$", full.names = TRUE)
      
      # Wczytaj dane z plików CSV
      all_data <- lapply(csv_files, read.csv)
      names(all_data) <- gsub("\\.csv$", "", basename(csv_files))
      
      # Uaktualnij dane i listę ubezpieczycieli
      data_list(all_data)
      updateSelectInput(session, "insurance", choices = names(all_data))
      
      # Ukryj spinner i overlay
      shinyjs::hide(id = "loadingOverlay")
      shinyjs::hide(id = "loadingSpinner")
    }
  })
  
  observeEvent(input$insurance, {
    req(input$insurance)
    filtered_data(data_list()[[input$insurance]])
    updateSelectInput(session, "column", choices = names(filtered_data()))
  })
  
  # Wykres histogramu
  output$histogramPlot <- renderPlot({
    req(filtered_data())
    column <- input$column
    req(column)
    
    ggplot(filtered_data(), aes_string(x = column)) +
      geom_histogram(binwidth = 5000, fill = "blue", color = "black", alpha = 0.7) +
      labs(title = paste("Rozkład", column), x = column, y = "Częstotliwość")
  })
  
  # Wyświetlanie statystyk
  output$statsTable <- renderDT({
    req(filtered_data())
    stats <- calculate_statistics(filtered_data())
    datatable(stats)
  })
  
  # Wykres kwantyli
  output$quantilePlot <- renderPlot({
    req(filtered_data())
    data <- filtered_data()
    quantiles <- c(0.01, 0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 0.95, 0.99, 0.995)
    
    quantile_data <- data.frame(
      Quantile = rep(quantiles, times = ncol(data)),
      Value = unlist(lapply(data, quantile, quantiles)),
      Variable = rep(names(data), each = length(quantiles))
    )
    
    ggplot(quantile_data, aes(x = Quantile, y = Value, color = Variable)) +
      geom_line() +
      geom_point() +
      labs(title = "Kwantyle dla każdej kolumny", x = "Kwantyl", y = "Wartość szkody") +
      theme(legend.position = "left")
  })
  
  observeEvent(input$generate_report, {
    req(data_list())
    req(input$save_path)
    
    generate_report(data_list(), input$save_path)
    
    showModal(modalDialog(
      title = "Raport wygenerowany",
      "Raport został pomyślnie zapisany w podanej lokalizacji.",
      easyClose = TRUE,
      footer = NULL
    ))
  })
}

shinyApp(ui = ui, server = server)
