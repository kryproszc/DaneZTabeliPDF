generate_initial_data <- function() {
  num_samples <- 100 # Stała liczba próbek
  data <- data.frame(
    Brutto = rnorm(num_samples, mean = 40000, sd = 10000),
    Brutto_Katastroficzny = rnorm(num_samples, mean = 20000, sd = 15000),
    Netto = rnorm(num_samples, mean = 40000, sd = 10000),
    Netto_Katastroficzny = rnorm(num_samples, mean = 10000, sd = 12000)
  )
  return(data)
}

# Zapisanie danych do pliku CSV
data <- generate_initial_data()
write.csv(data, "PZU.csv", row.names = FALSE)