library(shiny)
library(ggplot2)
library(DT)
library(shinycssloaders)
library(shinyjs)

# UI
shinyUI(fluidPage(
  useShinyjs(),
  inlineCSS(list(
    ".overlay" = "position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0, 0, 0, 0.5); z-index: 1000;",
    ".spinner" = "position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); z-index: 1001;"
  )),
  titlePanel("Aplikacja do wizualizacji"),
  
  navbarPage("Symulacje",
             tabPanel("Symulacje",
                      sidebarLayout(
                        sidebarPanel(
                          textInput("folder_path", "Ścieżka do folderu:", ""),
                          actionButton("load_data", "Pobierz dane"),
                          selectInput("insurance", "Wybierz ubezpieczyciela:", choices = NULL),
                          selectInput("column", "Wybierz kolumnę:", choices = NULL),
                          textInput("save_path", "Ścieżka do zapisu raportu:", ""),
                          actionButton("generate_report", "Generuj raport")
                        ),
                        mainPanel(
                          tabsetPanel(
                            id = "tabs", # Identyfikator zakładek
                            tabPanel("Histogram",
                                     h2("Histogram"),
                                     withSpinner(plotOutput("histogramPlot"))
                            ),
                            tabPanel("Statystyki",
                                     h2("Statystyki"),
                                     withSpinner(DTOutput("statsTable"))
                            ),
                            tabPanel("Kwantyle",
                                     h2("Kwantyle"),
                                     withSpinner(plotOutput("quantilePlot"))
                            )
                          )
                        )
                      )
             )
  ),
  div(id = "loadingOverlay", class = "overlay", style = "display: none;"),
  div(id = "loadingSpinner", class = "spinner", style = "display: none;", tags$img(src = "https://cdnjs.cloudflare.com/ajax/libs/timelinejs/2.36.0/css/loading.gif", height = "100"))
))
