
setwd("C:/Users/szczesnk/Desktop/KOd R/ShinyProject")
runApp()
