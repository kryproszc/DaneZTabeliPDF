library(shiny)
library(leaflet)
library(dplyr)
library(geosphere)

# Generowanie przykładowych danych
set.seed(123)
n <- 1000

data <- data.frame(
  Insurer = sample(0:5, n, replace = TRUE),
  Region = sample(0:15, n, replace = TRUE),
  Month = sample(0:11, n, replace = TRUE),
  SumValue = sample(1000:100000, n, replace = TRUE),
  IndexTable = 1:n,
  lat = runif(n, min = 49.0, max = 54.8),
  lon = runif(n, min = 14.1, max = 24.1)
)

# Funkcja do generowania nowych współrzędnych oddalonych o 200 metrów
generate_offset_coordinates <- function(lat, lon, distance) {
  bearing <- runif(1, 0, 360)  # Losowy kierunek
  new_coords <- destPoint(c(lon, lat), bearing, distance)
  return(new_coords)
}

# Wybór 100 losowych budynków
set.seed(123)  # Ustawienie ziarna dla powtarzalności wyników
sampled_buildings <- data %>% sample_n(100)

# Generowanie nowych współrzędnych dla wybranych budynków
offset_data <- sampled_buildings %>%
  rowwise() %>%
  mutate(
    new_coords = list(generate_offset_coordinates(lat, lon, 200)),
    new_lat = new_coords[[2]],
    new_lon = new_coords[[1]],
    Region = Region,  # Przenoszenie wartości Region
    Month = Month     # Przenoszenie wartości Month
  ) %>%
  select(-new_coords) %>%
  ungroup()

# Generowanie pozostałych kolumn dla nowych budynków
new_buildings <- offset_data %>%
  mutate(
    Insurer = sample(0:5, n(), replace = TRUE),
    SumValue = sample(1000:100000, n(), replace = TRUE)
  ) %>%
  select(IndexTable, Insurer, Region, Month, SumValue, new_lat, new_lon)

# Przemianowanie kolumn dla spójności
colnames(new_buildings) <- c("IndexTable", "Insurer", "Region", "Month", "SumValue", "lat", "lon")

# Aplikacja Shiny
ui <- navbarPage("Analiza budynków według ubezpieczycieli",
                 tabPanel("Wizualizacja budynków",
                          fluidPage(
                            fluidRow(
                              column(3,
                                     selectInput("insurers", "Wybierz ubezpieczycieli do wyświetlenia:", 
                                                 choices = unique(data$Insurer), multiple = TRUE),
                                     selectInput("highlight", "Wybierz ubezpieczyciela do wyróżnienia:", 
                                                 choices = unique(data$Insurer), selected = 0),
                                     selectInput("regions", "Wybierz województwa do wyświetlenia:", 
                                                 choices = unique(data$Region), multiple = TRUE),
                                     selectInput("months", "Wybierz miesiące do wyświetlenia:", 
                                                 choices = 0:11, multiple = TRUE),
                                     numericInput("sumValueMin", "Minimalna suma ubezpieczenia:", value = NA, min = 0, step = 1000),
                                     numericInput("sumValueMax", "Maksymalna suma ubezpieczenia:", value = NA, min = 0, step = 1000),
                                     selectInput("mapTiles", "Wybierz typ mapy:", 
                                                 choices = c("OpenStreetMap Mapnik" = "OpenStreetMap.Mapnik",
                                                             "Esri WorldStreetMap" = "Esri.WorldStreetMap",
                                                             "Esri WorldImagery" = "Esri.WorldImagery",
                                                             "OpenTopoMap" = "OpenTopoMap"))
                              ),
                              column(9,
                                     leafletOutput("map", height = "800px")
                              )
                            )
                          )
                 ),
                 tabPanel("Symulacje",
                          h2("Symulacje")
                 )
)

server <- function(input, output, session) {
  
  current_zoom <- reactiveVal(4)
  current_center <- reactiveVal(c(52, 19))
  
  observeEvent(input$mapTiles, {
    current_zoom(input$map_zoom)
    current_center(input$map_center)
  })
  
  output$map <- renderLeaflet({
    leaflet() %>%
      addProviderTiles(providers$OpenStreetMap.Mapnik) %>%
      setView(lng = 19, lat = 52, zoom = 4)
  })
  
  observeEvent(input$mapTiles, {
    proxy <- leafletProxy("map") %>%
      clearTiles() %>%
      addProviderTiles(switch(input$mapTiles,
                              "OpenStreetMap.Mapnik" = providers$OpenStreetMap.Mapnik,
                              "Esri.WorldStreetMap" = providers$Esri.WorldStreetMap,
                              "Esri.WorldImagery" = providers$Esri.WorldImagery,
                              "OpenTopoMap" = providers$OpenTopoMap)) %>%
      setView(lng = current_center()[2], lat = current_center()[1], zoom = current_zoom())
  })
  
  observe({
    leafletProxy("map") %>%
      clearMarkers() %>%
      clearShapes()
    
    # Sprawdzenie, czy wybrano jakichkolwiek ubezpieczycieli
    if (is.null(input$insurers) || length(input$insurers) == 0) {
      filtered_data <- data
      filtered_new_buildings <- new_buildings
      filtered_sampled_buildings <- sampled_buildings
    } else {
      filtered_data <- data %>% filter(Insurer %in% input$insurers)
      filtered_new_buildings <- new_buildings %>% filter(Insurer %in% input$insurers)
      filtered_sampled_buildings <- sampled_buildings %>% filter(Insurer %in% input$insurers)
    }
    
    # Sprawdzenie, czy wybrano jakiekolwiek województwa
    if (!is.null(input$regions) && length(input$regions) > 0) {
      filtered_data <- filtered_data %>% filter(Region %in% input$regions)
      filtered_new_buildings <- filtered_new_buildings %>% filter(Region %in% input$regions)
      filtered_sampled_buildings <- filtered_sampled_buildings %>% filter(Region %in% input$regions)
    }
    
    # Sprawdzenie, czy wybrano jakiekolwiek miesiące
    if (!is.null(input$months) && length(input$months) > 0) {
      filtered_data <- filtered_data %>% filter(Month %in% input$months)
      filtered_new_buildings <- filtered_new_buildings %>% filter(Month %in% input$months)
      filtered_sampled_buildings <- filtered_sampled_buildings %>% filter(Month %in% input$months)
    }
    
    # Sprawdzenie, czy wybrano zakres sumy ubezpieczenia
    if (!is.na(input$sumValueMin)) {
      filtered_data <- filtered_data %>% filter(SumValue >= input$sumValueMin)
      filtered_new_buildings <- filtered_new_buildings %>% filter(SumValue >= input$sumValueMin)
      filtered_sampled_buildings <- filtered_sampled_buildings %>% filter(SumValue >= input$sumValueMin)
    }
    if (!is.na(input$sumValueMax)) {
      filtered_data <- filtered_data %>% filter(SumValue <= input$sumValueMax)
      filtered_new_buildings <- filtered_new_buildings %>% filter(SumValue <= input$sumValueMax)
      filtered_sampled_buildings <- filtered_sampled_buildings %>% filter(SumValue <= input$sumValueMax)
    }
    
    # Mapa z oryginalnymi i nowymi budynkami
    leafletProxy("map") %>%
      addCircleMarkers(data = filtered_data,
                       ~lon, ~lat,
                       color = ~ifelse(Insurer == input$highlight, "red", "black"),
                       radius = ~log(SumValue) / 2,
                       popup = ~paste("Insurer:", Insurer, "<br>",
                                      "Region:", Region, "<br>",
                                      "Month:", Month + 1, "<br>",
                                      "SumValue:", SumValue, "<br>",
                                      "IndexTable:", IndexTable),
                       fillOpacity = 0.7,
                       group = "Original Buildings") %>%
      addCircleMarkers(data = filtered_new_buildings,
                       ~lon, ~lat,
                       color = ~ifelse(Insurer == input$highlight, "red", "blue"),
                       radius = 5,
                       popup = ~paste("Insurer:", Insurer, "<br>",
                                      "Region:", Region, "<br>",
                                      "Month:", Month + 1, "<br>",
                                      "SumValue:", SumValue, "<br>",
                                      "IndexTable:", IndexTable),
                       fillOpacity = 0.7,
                       group = "New Buildings") %>%
      addCircles(data = filtered_sampled_buildings,
                 ~lon, ~lat,
                 radius = 200,
                 color = "green",
                 fill = FALSE,
                 group = "Circles") %>%
      addLayersControl(
        overlayGroups = c("Original Buildings", "New Buildings", "Circles"),
        options = layersControlOptions(collapsed = FALSE)
      ) %>%
      addLegend(position = "bottomright",
                colors = c("black", "blue", "red", "green"),
                labels = c("Original Buildings", "New Buildings", "Highlighted Insurer", "Circles"),
                title = "Building Types") %>%
      addMiniMap(toggleDisplay = TRUE)
  })
}

shinyApp(ui, server)
