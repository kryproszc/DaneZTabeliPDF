library(shiny)
library(sf)
library(ggplot2)
library(dplyr)
library(leaflet)
library(lwgeom)
library(shinycssloaders)
library(shinyjs)

# Load shapefiles for gminy, powiaty, and wojewodztwa
gminy <- st_read("C:/Users/szczesnk/Desktop/KOd R/ShinyProject/gminy/gminy.shp")
powiaty <- st_read("C:/Users/szczesnk/Desktop/KOd R/ShinyProject/powiaty/powiaty.shp")
wojewodztwa <- st_read("C:/Users/szczesnk/Desktop/KOd R/ShinyProject/wojewodztwa/wojewodztwa.shp")

# Fix invalid geometries
gminy <- st_make_valid(gminy)
powiaty <- st_make_valid(powiaty)
wojewodztwa <- st_make_valid(wojewodztwa)

# Simplify geometries for faster rendering
gminy <- st_simplify(gminy, dTolerance = 100)
powiaty <- st_simplify(powiaty, dTolerance = 100)
wojewodztwa <- st_simplify(wojewodztwa, dTolerance = 100)

# Transform CRS to WGS84
gminy <- st_transform(gminy, crs = 4326)
powiaty <- st_transform(powiaty, crs = 4326)
wojewodztwa <- st_transform(wojewodztwa, crs = 4326)

# Generate sample fire data
set.seed(123)
n <- 12000
data <- data.frame(
  Insurer = sample(c("Insurer A", "Insurer B", "Insurer C", "Insurer D", "Insurer E", "Insurer F"), n, replace = TRUE),
  Latitude = runif(n, 49.0, 55.0),
  Longitude = runif(n, 14.0, 24.0),
  Region = sample(0:15, n, replace = TRUE),
  Month = sample(1:12, n, replace = TRUE),
  SumValue = runif(n, 1000, 100000),
  IndexTable = 0:(n-1)
)

# Convert data to sf object
punkty <- st_as_sf(data, coords = c("Longitude", "Latitude"), crs = 4326)

# Create Shiny app
ui <- fluidPage(
  useShinyjs(),
  inlineCSS(list(
    ".overlay" = "position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0, 0, 0, 0.5); z-index: 1000;",
    ".spinner" = "position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); z-index: 1001;"
  )),
  titlePanel("Analiza Pożarów w Jednostkach Administracyjnych"),
  sidebarLayout(
    sidebarPanel(
      selectInput("division", "Wybierz poziom podziału:",
                  choices = list("Gminy" = "gminy", "Powiaty" = "powiaty", "Województwa" = "wojewodztwa"),
                  selected = "wojewodztwa"),
      selectInput("variable", "Wybierz zmienną do analizy:",
                  choices = list("Liczba Pożarów" = "LiczbaPozarow",
                                 "Suma Strat" = "SumValue",
                                 "Średnia Strata" = "MeanValue")),
      sliderInput("top_n", "Liczba jednostek do wyświetlenia:", 
                  min = 1, max = 20, value = 10),
      selectizeInput("months", "Wybierz miesiące:", 
                     choices = c("Wszyscy" = "all", 1:12), 
                     selected = "all", multiple = TRUE),
      selectizeInput("insurers", "Wybierz ubezpieczycieli:", 
                     choices = c("Wszyscy" = "all", unique(data$Insurer)), 
                     selected = "all", multiple = TRUE),
      radioButtons("top_type", "Wybierz typ jednostek:",
                   choices = list("Największe" = "largest", "Najmniejsze" = "smallest"))
    ),
    mainPanel(
      withSpinner(plotOutput("barPlot")),
      withSpinner(leafletOutput("mapPlot")),
      withSpinner(plotOutput("monthPlot"))
    )
  ),
  div(id = "loadingOverlay", class = "overlay", style = "display: none;"),
  div(id = "loadingSpinner", class = "spinner", style = "display: none;", tags$img(src = "https://cdnjs.cloudflare.com/ajax/libs/timelinejs/2.36.0/css/loading.gif", height = "100"))
)

server <- function(input, output, session) {
  
  options(shiny.maxRequestSize = 30*1024^2) # Zwiększenie limitu do 30 MB
  
  observeEvent(input$division, {
    shinyjs::show(id = "loadingOverlay")
    shinyjs::show(id = "loadingSpinner")
    
    # Ukrycie spinnera i overlay po zakończeniu przetwarzania
    on.exit({
      shinyjs::hide(id = "loadingOverlay")
      shinyjs::hide(id = "loadingSpinner")
    }, add = TRUE)
    
    selectedData <- reactive({
      message("Przygotowywanie danych do analizy")
      punkty_transformed <- st_transform(punkty, st_crs(get(input$division)))
      
      # Filtruj dane na podstawie wybranych miesięcy i ubezpieczycieli
      if (!("all" %in% input$months)) {
        punkty_transformed <- punkty_transformed[punkty_transformed$Month %in% input$months, ]
      }
      if (!("all" %in% input$insurers)) {
        punkty_transformed <- punkty_transformed[punkty_transformed$Insurer %in% input$insurers, ]
      }
      
      if (nrow(punkty_transformed) == 0) {
        return(NULL)
      }
      
      punkty_jednostki <- st_join(punkty_transformed, get(input$division), join = st_intersects)
      
      if (input$variable == "LiczbaPozarow") {
        df <- aggregate(IndexTable ~ JPT_NAZWA_, data = punkty_jednostki, length)
        names(df)[2] <- "Value"
      } else if (input$variable == "SumValue") {
        df <- aggregate(SumValue ~ JPT_NAZWA_, data = punkty_jednostki, sum)
        names(df)[2] <- "Value"
      } else if (input$variable == "MeanValue") {
        df <- aggregate(SumValue ~ JPT_NAZWA_, data = punkty_jednostki, mean)
        names(df)[2] <- "Value"
      }
      message("Dane do analizy przygotowane")
      df
    })
    
    output$barPlot <- renderPlot({
      df <- selectedData()
      req(df)
      
      top_n <- input$top_n
      
      if (input$top_type == "largest") {
        df <- df[order(-df$Value), ][1:top_n, ]
      } else {
        df <- df[order(df$Value), ][1:top_n, ]
      }
      
      message("Generowanie wykresu słupkowego")
      ggplot(df, aes(x = reorder(JPT_NAZWA_, Value), y = Value, fill = Value)) +
        geom_bar(stat = "identity") +
        ggtitle(paste("Top", top_n, ifelse(input$top_type == "largest", "Jednostek z Najwyższą", "Jednostek z Najniższą"), input$variable)) +
        xlab(input$division) +
        ylab(input$variable) +
        theme_minimal() +
        coord_flip() +
        scale_fill_gradient(low = "lightblue", high = "darkblue")
    })
    
    output$mapPlot <- renderLeaflet({
      df <- selectedData()
      req(df)
      
      message("Generowanie mapy")
      
      jednostki_data <- merge(get(input$division), df, by.x = "JPT_NAZWA_", by.y = "JPT_NAZWA_", all.x = TRUE)
      jednostki_data$Value[is.na(jednostki_data$Value)] <- 0  # Zastąpienie brakujących wartości zerami
      
      pal <- colorNumeric(palette = "YlOrRd", domain = jednostki_data$Value, na.color = "transparent")
      
      leaflet(jednostki_data) %>%
        addTiles() %>%
        setView(lng = 19.1451, lat = 51.9194, zoom = 6) %>%  # Ustawienie widoku na Polskę
        # Ustawienie widoku na Polskę
        addPolygons(fillColor = ~ifelse(Value == 0, "transparent", pal(Value)), color = "#BDBDC3", weight = 1,
                    fillOpacity = 0.7, smoothFactor = 0.5,
                    popup = ~paste(JPT_NAZWA_, "<br>", input$variable, ": ", Value)) %>%
        addLegend(pal = pal, values = ~Value, opacity = 0.7, title = input$variable, position = "bottomright")
    })
    
    output$monthPlot <- renderPlot({
      df <- selectedData()
      req(df)
      
      message("Generowanie wykresu miesięcznego")
      
      punkty_filtered <- st_transform(punkty, st_crs(get(input$division)))
      
      if (!("all" %in% input$months)) {
        punkty_filtered <- punkty_filtered[punkty_filtered$Month %in% input$months, ]
      }
      if (!("all" %in% input$insurers)) {
        punkty_filtered <- punkty_filtered[punkty_filtered$Insurer %in% input$insurers, ]
      }
      
      punkty_gminy <- st_join(punkty_filtered, get(input$division), join = st_intersects)
      
      if (input$variable == "LiczbaPozarow") {
        liczba_pozarow_miesiac <- punkty_gminy %>%
          group_by(Month) %>%
          summarise(Value = n())
      } else if (input$variable == "SumValue") {
        liczba_pozarow_miesiac <- punkty_gminy %>%
          group_by(Month) %>%
          summarise(Value = sum(SumValue))
      } else if (input$variable == "MeanValue") {
        liczba_pozarow_miesiac <- punkty_gminy %>%
          group_by(Month) %>%
          summarise(Value = mean(SumValue))
      }
      
      ggplot(liczba_pozarow_miesiac, aes(x = Month, y = Value)) +
        geom_line(group = 1) +
        geom_point() +
        ggtitle(paste(input$variable, "w Poszczególnych Miesiącach")) +
        xlab("Miesiąc") +
        ylab(input$variable) +
        scale_x_continuous(breaks = 1:12, labels = month.name) +
        theme_minimal()
    })
  })
}

shinyApp(ui, server)
